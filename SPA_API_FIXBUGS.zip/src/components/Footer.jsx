import React from "react";

function Footer() {
  return (
    <footer className="footer">
      <p>Hendri Wahyu Perdana &copy; Copyright 2024</p>
    </footer>
  );
}

export default Footer;
