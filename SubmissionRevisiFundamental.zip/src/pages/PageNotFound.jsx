import React from "react";

function PageNotFound() {
  return (
    <section>
      <h1>404</h1>
      <p>Page Not Found</p>
    </section>
  );
}

export default PageNotFound;
